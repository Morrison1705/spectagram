# spectagram-etapa-6
solución del proyecto c86
